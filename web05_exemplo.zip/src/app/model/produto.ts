export class Produto {
    public valor : number =0;
    public nome: string = "";
    public descritivo: string = "";
    public codigo: number=0;
    public keywords: string = "";
    public quantidade: number=0;
    public promo: number=0;
    public destaque: number = 0;
}
