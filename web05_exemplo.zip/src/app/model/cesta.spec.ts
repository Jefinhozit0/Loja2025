import { Cesta } from './cesta';

describe('Cesta', () => {
  it('should create an instance', () => {
    expect(new Cesta()).toBeTruthy();
  });
});
