export class Cliente {
    codigo: number = 0;
    nome: string = "";
    email: string = "";
    logradouro: string = "";
    senha: string = "";
    telefone: string = "";
    documento:string = "";
}
