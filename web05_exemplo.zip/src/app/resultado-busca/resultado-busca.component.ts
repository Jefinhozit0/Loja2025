import { Component } from '@angular/core';

@Component({
  selector: 'app-resultado-busca',
  standalone: true,
  imports: [],
  templateUrl: './resultado-busca.component.html',
  styleUrl: './resultado-busca.component.css'
})
export class ResultadoBuscaComponent {

}
